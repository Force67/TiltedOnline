# Tilted Reverse

[![Build Status](https://dev.azure.com/TiltedPhoques/TiltedReverse/_apis/build/status/tiltedphoques.TiltedReverse?branchName=master)](https://dev.azure.com/TiltedPhoques/TiltedReverse/_build/latest?definitionId=2&branchName=master)

This library covers our reverse engineering needs for game clients
